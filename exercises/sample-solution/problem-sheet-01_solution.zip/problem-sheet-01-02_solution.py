# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# +
import numpy as np
import pandas as pd
import scipy
import scipy.stats

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
prop_cycle = plt.rcParams['axes.prop_cycle']
colors = prop_cycle.by_key()['color']

# %matplotlib inline
# -

# # Exercise 1.2: a first visualization task.
# The file mpg-data.csv contains the mpg example dataset from the ggplot2 library (https:
# //ggplot2.tidyverse.org/reference/mpg.html). The dataset contains information about the
# fuel efficiency of various car models. It can be imported as pandas data frame via the read_csv
# function. For each car/model, the column class gives the category/class (e.g. ‘suv’ or ‘compact’),
# the column displ gives the engine displacement in liters, and the column hwy gives the fuel
# efficiency in miles per gallon on highways.

mpg = pd.read_csv("./mpg-data.csv")

# ### 1. 
# Split the dataset into different car classes. For each class, perform a linear regression on
# the dependency of hwy on displ.

classes = np.unique(mpg["class"])
# determine the number of classes for further plotting
len(classes)

# ### 2 
#
# Give a scatter plot of hwy against displ. Make sure that the class of each car can be
# determined from the plot. Add straight lines showing the regression lines for each class.
# Make sure that your plot has appropriate axes labels and legends.
#
# Hint: Code from the examples _2023-04-17_Example-Anscombe_ and _2023-04-17_WorldDemographics-
# Test-01_ can be helpful for this exercise.

markerList = ["o","x","s","v","^","2","*"]

# +
fig = plt.figure()
ax = fig.add_subplot()
# go through the classes
for i,cl in enumerate(classes):
    x = mpg["displ"][mpg["class"]==cl]
    y = mpg["hwy"][mpg["class"]==cl]

    plt.scatter(x,y,c=colors[i],label=cl,\
            marker=markerList[i])
    xref = np.array([min(x),max(x)])
    # perform regression for selected class
    regression = scipy.stats.linregress(x,y)
    # add regression lines for each class
    plt.plot(xref,regression.slope*xref+regression.intercept,c=colors[i])

plt.xlabel("Engine displacement in litres")
plt.ylabel("Miles per gallon on highway")
plt.legend()
plt.show()
