# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# +
import numpy as np
import scipy
import imageio

import csv

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm

import scipy.io as sciio

from matplotlib.animation import FuncAnimation

matplotlib.rc('image', interpolation='nearest')
matplotlib.rc('figure',facecolor='white')
matplotlib.rc('image',cmap='viridis')

prop_cycle = plt.rcParams['axes.prop_cycle']
colors = prop_cycle.by_key()['color']

# %matplotlib inline
# -

# # 1. Professors, students and papers
# In our dataset there are 7 persons, indexed by numbers $\{0,\ldots,6\}$. Persons $0$ and $1$ are professors, persons $2$ to $6$ are doctoral students. Students $\{2,4,5\}$ are advised by professor $0$; students $\{3,6\}$ are advised by professor $1$. Together they have published four papers, indexed by numbers $\{0,\ldots,3\}$. The amount of contribution to each paper is captured by the following list where each triple $[a,b,c]$ indicates that person $b$ contributed to paper $a$ a fraction of $c$, normalized such that the total contribution to each paper sums to 1:
# $[[0, 0, 0.4], [0, 2, 0.6], [1, 0, 0.3], [1, 4, 0.3], [1, 5, 0.2], [1, 3, 0.2],$
#  $[2, 0, 0.2], [2, 1, 0.4], [2, 3, 0.4], [3, 1, 0.3], [3, 3, 0.2], [3, 6, 0.5]]$
#
# Visualize this dataset. Your visualization should contain the following information:
# * role of each person, student-advisor relation,
# * contribution (and strength thereof) to papers, total contribution of each person.
#
# You can complete this exercise with any software you want, simply include the resulting figure to your submitted pdf.

# +
# Specify all given data

# role of each person; 0: prof, 1: student
person_roles = np.array([0,0,1,1,1,1,1],dtype=int)

# advisor relation: each tuple [i,j] indicates that 
# student i is adviced by prof j
advisor_relation=np.array([\
        [2,0],
        [3,1],
        [4,0],
        [5,0],
        [6,1]
        ],dtype=int)

# paper contributions
paper_contributions=\
        [[0, 0, 0.4],
        [0, 2, 0.6],
        [1, 0, 0.3],
        [1, 4, 0.3],
        [1, 5, 0.2],
        [1, 3, 0.2],
        [2, 0, 0.2],
        [2, 1, 0.4],
        [2, 3, 0.4],
        [3, 1, 0.3],
        [3, 3, 0.2],
        [3, 6, 0.5]]

# +
# some small preprocessing and design choices

nPersons = person_roles.shape[0]
nPapers = paper_contributions[-1][0] + 1


# we assign two colors to represent supervision relationship
colb =np.array([0,0,0.5])
colr = np.array([0.5,0,0])

# array for all persons
person_colors = np.zeros((nPersons,3),dtype=np.double)
# first color the professors
person_colors[0] = colb
person_colors[1] = colr
# then color all their students
for x,y in advisor_relation:
    person_colors[x]=colb if y==0 else colr

# also compute the persons' contribution
person_contribution=np.zeros((nPersons,),dtype=np.double)
for x,y,z in paper_contributions:
    person_contribution[y]+=z

# and select two distinct markers to represent professors and students
markerList=["X","o"]

# +
# First we are going to strive for a simple automated solution

# plotting parameters: x coordinate for nodes
posx_people = 0
posx_papers = 3
buffer = 0.5 # just a small offset for setting limits

# assign x coordinates as above and y coordinates as index
person_positions = np.zeros((nPersons,2))
person_positions[:,1] = range(nPersons) 
person_positions[:,0] = posx_people

paper_positions = np.zeros((nPapers,2))
paper_positions[:,1] = range(nPapers) 
paper_positions[:,0] = posx_papers


fig = plt.figure(figsize=(4,6))

# setup the aspect to have consistency
ax_people = fig.add_subplot(aspect=1.)

ax_people.set_xlim([posx_people-buffer,posx_papers+buffer])
ax_people.set_ylim([np.min(person_positions[:,1])-buffer,np.max(person_positions[:,1])+buffer])

# plot the people with designated markers (professor/student), 
# color (supervision), size (total contribution to all papers)
for role in [0,1]:
    indicator = (role==person_roles)
    ax_people.scatter(person_positions[indicator,0],person_positions[indicator,1],\
            c = person_colors[indicator],s=800*person_contribution[indicator],\
            marker=markerList[role])

# erase unnecessary ticks
ax_people.set_xticks([])
ax_people.set_yticks(range(nPersons))    
ax_people.set_ylabel("Contributors")


# create a second y-axis to enumerate the papers
ax_papers = ax_people.twinx()

# set the exact same parameters for consistency when drawing edges
ax_papers.set_xlim([posx_people-buffer,posx_papers+buffer])
ax_papers.set_ylim([np.min(person_positions[:,1])-buffer,np.max(person_positions[:,1])+buffer])
ax_papers.set_aspect(1.)

# plot the papers in a new color with a new marker
ax_papers.scatter(paper_positions[:,0],paper_positions[:,1],c="k",marker="s")

# plot the edges to show contributions from each person to each paper:
# here the contribution is shown with the width and with color
# from a presected colorscheme, but any one of those might be
# sufficient
for x,y,z in paper_contributions:
    color = plt.cm.viridis(z) 
    posa = person_positions[y]
    posb = paper_positions[x]
    cb = ax_papers.plot([posa[0],posb[0]],[posa[1],posb[1]],color=color,zorder=-1,lw=10*z)

# set only the necessary ticks
ax_papers.set_yticks(range(nPapers))    
ax_papers.set_ylabel("Papers")

# the next two lines allow showing the nodes on top of the edges
# we first select the order of layers
ax_people.set_zorder(ax_papers.get_zorder()+1)
# and then "add transparency" to the layer on the top
ax_people.set_frame_on(False)


plt.tight_layout()
plt.show()

# +
# Another intuitive implementation would be to group the
# persons (in this case - manually) by supervision
# and show them as a graph without a relation to the grid
# Note: In this case we will have to annotate the "names" of
# people and the papers (we use indices, but in a more practical 
# application it's one more step to add the names/other identifiers)

person_positions = np.array([
    [0,0],[0,-2.5],
    [0,1],[0,-2],[0,0],[0,-1],[0,-3] 
])
person_positions[person_roles==1,0] = posx_people
person_positions[4,0] += 0.6

paper_positions=np.array([
    [0,0.5],[0,-1],[0,-2],[0,-3]
])
paper_positions[:,0] = posx_papers

text_offset_x = -0.05
text_offset_y = -0.05

# +
fig = plt.figure(figsize=(6,6))
ax = fig.add_subplot(aspect=1.)

ax.set_xlim([posx_people-buffer,posx_papers+buffer])
ax.set_ylim([np.min(person_positions[:,1])-buffer,np.max(person_positions[:,1])+buffer])

for role in [0,1]:
    indicator=(role==person_roles)
    plt.scatter(person_positions[indicator,0],person_positions[indicator,1],\
            c=person_colors[indicator],s=800*person_contribution[indicator],\
            marker=markerList[role])
    
for person in range(nPersons):
    plt.annotate("{}".format(person),\
                 (person_positions[person,0]+text_offset_x,person_positions[person,1]+text_offset_y),\
                 c="cyan", size="large",weight="bold")
    
plt.scatter(paper_positions[:,0],paper_positions[:,1],c="k",s=300)
for paper in range(nPapers):
    plt.annotate("{}".format(paper),\
                 (paper_positions[paper,0]+text_offset_x,paper_positions[paper,1]+text_offset_y),\
                 c="red", size="large",weight="bold")

for x,y,z in paper_contributions:
    color = plt.cm.viridis(z) 
    posa=person_positions[y]
    posb=paper_positions[x]
    plt.plot([posa[0],posb[0]],[posa[1],posb[1]],c=color,zorder=-1,lw=10*z)

    
plt.xticks([])    
plt.yticks([])

plt.tight_layout()
plt.show()
# -

# # 2 animating the law of large numbers
#

# Consider a univariate standard normal distribution (i.e. zero mean and unit standard deviation) and let $(x_i)_{i=1}^N$ be independent samples from it (which can numerically easily be approximated with _numpy.random.normal_). As shown earlier in the lecture, for given $N > 0$, one can use the points, e.g. in a histogram or via a kernel density estimation, to estimate the density of the underlying normal distribution. For fixed parameters of the density estimation (width of bins or bandwidth of kernel), this estimate should stabilize as $N \to \infty$. This is an instance of the law of large numbers. 
#
# Create an animation that shows this effect, i.e. the evolution of the estimated density with increasing $N$, in comparison with the true underlying density.
#
# _Hints_: Feel free to use code for creating animations that was presented in the lecture. Your submission should contain a screenshot of your animation as well as the generating code, in a way that can easily be extracted for reproduction.

# +
# setup the distribution parameters
xmax=3
nBins = 25
nParticles = int(1E3)
nSteps = 100

# get empirical histograms
data = np.random.normal(size=nParticles)
histData = np.zeros((nSteps,nBins),dtype=np.double)
for i in range(nSteps):
    nIncl = int(nParticles*(i+1)/nSteps)
    histData[i,:],binspec = np.histogram(data[:nIncl],bins=nBins,range=[-xmax,xmax],density=True)

# +
# let us first see how the limit density looks like

# get limit density
x=np.linspace(-xmax,xmax,num=1000)
y=np.exp(-x**2/2)/(np.sqrt(2*np.pi))

# plot it (static plot, no animation so far)
for i in [nSteps-1]:
    plt.plot(binspec,np.concatenate((np.array([0.]),histData[i,:])),c=cm.viridis(i/nSteps),
            drawstyle="steps-pre")
plt.plot(x,y,c="r",lw=2)
plt.show()

# +
# We now proceed to make the required animation using the code
# from the lectures as the base

# if you are working in jupyter notebooks, you might need to add
# the next line (or the next 2 lines, depending in your configuration)
# to view the animations
# %matplotlib notebook
plt.rcParams["animation.html"] = "jshtml"

fig = matplotlib.figure.Figure(figsize=(5,3))
ax = fig.add_subplot()

# most plot commands return an object with which one can later manipulate the displayed data
# for dynamic plot keep reference to these objects
ax.plot(x,y,c="k",lw=1)

ax.set_xlim([-xmax,xmax])
ymax=np.max(histData)*1.1
ax.set_ylim([0.,ymax])

pltobj_line = ax.plot([],[],c="r",lw=2,drawstyle="steps-pre")[0]
pltobj_text= ax.text(-xmax+0.25,ymax-0.1,"")


def update(t):
    # compute updated locations of vertices
    hist = np.concatenate((np.array([0.]),histData[t,:]))
    pltobj_line.set_data(binspec,hist)
    pltobj_text.set_text("N={:d}".format(int(nParticles*(t+1)/nSteps)))

# create animation object, arguments:
ani = FuncAnimation(fig, update, frames=range(nSteps),
        blit=True,interval=5000/nSteps)

ani
