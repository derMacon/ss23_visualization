# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# # General suggestions
# * ### Please use *surnames* in the submission file name. 
# * ###  Please submit one file pro group pro problem sheet. If you would like to provide several files, pack them into a .zip folder.
# * ### Please include the code into the submissions and make sure that it can be easily tested (that is, can be run or copied) _as well as_ the produced images.
# * ###  Please write comments, they are very helpful.
# * ### Don't hesitate to use the materials from the lectures (the script, the video, and the code): they are quite useful when solving the problem sheets.

# +
# libraries
import numpy as np
import imageio
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm

# %matplotlib inline
# -

# # 2.1 Customer survey

# A local shop has performed a customer survey where participants answered four questions on a rating scale from *excellent* to *appalling*. Not all submitted questionnaires were necessarily complete. The questions and the obtained numbers of answers for each rating are given below:
#
# ![image.png](attachment:image.png)
#
# You are tasked with visualizing the data. Keep the following criteria in mind:
# * The plot should reveal *cumulative* information about the survey. For instance, what fraction of customers rates the service at least average or better? 
# * Both the relative distribution of ratings as well as the absolute number of answers for each question should be represented visually, not necessarily within a single plot.
# * Though not strictly necessary, think about how color can be used to make the plot more intuitive.

# +
# process the data from the task
questions = ["Quality of products",
            "Do you like our shop?",
            "Customer service",
            "Overall experience"]

levels = ["excellent","good","average","poor","appalling","no answer"]
data = np.array([[191, 184, 133,  82,  25],
                 [448,  16, 12,  146, 0],
                 [ 63, 127, 171, 191,  58],
                 [ 40, 100, 126,  52,  26]])

nQuestions,nLevels = data.shape

# +
# we are interested (among other things) in the relative distribution of
# the rating, so we process the data to plot later:

# renormalize answers to get the relative distribution
dataRelative = np.zeros(shape = (nQuestions,nLevels+1))
dataRelative[:,1:] = data
dataRelative = dataRelative/np.sum(dataRelative,axis=1).reshape((-1,1))
# compute the cumulative sum to make the plotting of cumulative
# (stacked) bar chart easier
dataRelative = np.cumsum(dataRelative,axis=1)

# compute the sum of answers (i.e., number of respondents for each question)
dataSum=np.sum(data,axis=1)
# -

# pick the colormap: RdYlGn == Red-Yellow-Green, intuitive representation
# for data going from bad (red) to good (green)
colors = [cm.RdYlGn(1-i/(nLevels-1)) for i in range(nLevels)]

# +
# now we plot a complex plot from 3 subplots:
# (1) stacked bar chart representing the relative distribution 
#     of answers (using the selected colorscheme)
# (2) bar chart representing the absolute number of answers
# (3) legend 

# we also must strive to show the question formulations in full even though
# they are rather long

fig=plt.figure(figsize=(10,3))

# make an array to represent the questions: simply a range 1:nQuestions
y_quest = np.arange(nQuestions)

# parameter of the barcharts
height=1.

# create a grid for subplots
gs = fig.add_gridspec(5, 5)



# create subplot nr1: stacked bar charts
ax1 = fig.add_subplot(gs[1:, :-1])

# for each of the levels (from appaling to excellent)
for i in range(nLevels):
    # the horizontal barchart with parameters:
    # -y_quest as the y-coordinate of the bars
    # dataRelative[:,i+1]-dataRelative[:,i] as the width
    # parameter left sets the horizontal baseline
    # parameter height sets the heigt
    # parameter color sets the color
    ax1.barh(-y_quest,dataRelative[:,i+1]-dataRelative[:,i],left=dataRelative[:,i],\
             height=height,color=colors[i])

# adjust the limits so that the plot takes the entire axes
ax1.set_xlim([0,1])
ax1.set_ylim([height*(-nLevels+1.5),height*0.5])

# y-ticks correspond to the questions
ax1.set_yticks(-y_quest)
ax1.set_yticklabels(questions)

# x-ticks in this relative distribution plot represent percents of respondents
# pick the number of intervals (= the number of ticks displayed -1)
xticks_n = 5
# pick the locations of the ticks
xticks_v = [i/xticks_n for i in range(xticks_n+1)]
# set up the lables for the ticks in the format "x %"
xticks_l=["{:d}%".format(int(i*100)) for i in xticks_v]
# apply to the plot
ax1.set_xticks(xticks_v)
ax1.set_xticklabels(xticks_l)


# create subplot nr2: number of respondents
ax2 = fig.add_subplot(gs[1:, -1])
# using the same horizontal barchat function, plot the distribution 
# of respondents: for each question, how many people answered
# note: here a distinctly different color (gray) is used so that
# it is clear that it does not belong to the selected main colorbar
ax2.barh(-y_quest,dataSum,height=height,color=cm.gray(0.7))
# annotate the number of repondents on top of the bars
for i in range(nQuestions):
    ax2.text(10,-i,"{:d}".format(int(dataSum[i])),ha="left",va="center")

# adjust the limits
ax2.set_xlim([0,np.max(dataSum)])
ax2.set_ylim([height*(-nLevels+1.5),height*0.5])
# turn off the ticks and ticklabels
ax2.set_yticks([])
ax2.set_xticks([])
# make a label to help understand the plot
ax2.yaxis.set_label_position("right")
ax2.set_ylabel("Number of answers")


# create subplot nr3: legend
ax3 = fig.add_subplot(gs[0, :-1])
# make the legend manually using the same barh function + annotate the
# corresponding value
for i in range(nLevels):
    ax3.barh([0],1/nLevels,left=i/nLevels,height=height,color=colors[i])
    ax3.text((i+0.5)/nLevels,0,s=levels[i],ha="center",va="center")
# adjust the limits and ticks
ax3.set_xlim([0,1])
ax3.set_ylim([height*(-0.5),height*0.5])
ax3.set_yticks([])
ax3.set_xticks([])


plt.tight_layout()
plt.show()
# -

# ## Side comments: what can be seen from this plot?
#
# * Showing only relative distribution or only absolute one separately can not convey the same message as this combined type of plot.
#  
# * The second question, *Do you like our shop?* seems to be out of sync with the other questions, so perhaps a different formulation or different rating scale should have been used in the questionnaire.
#
# * Much fewer people answered the last question than the other ones. It might mean that the question is not clear enough or the scale is not appropriate, so people skip the question.
#
# * Customer service is somewhat lacking.

# # 2.2 Visualizing the exponential function

# The exponential function takes complex numbers to complex numbers, $\mathbb{C} \ni z \mapsto e^z \in \mathbb{C}$. 
#
# Identifying $\mathbb{C}$ with $\mathbb{R}^2$ in the usual way, $z=x+i \cdot y$ for $z \in \mathbb{C}$, $(x, y) \in \mathbb{R}^2$ and $i$ being the imaginary unit, the exponential function can be interpreted as a map from $\mathbb{R}^2$ to $\mathbb{R}^2$. 
#
# In this representation, it can be written as
# $$\begin{pmatrix} x \\ y \end{pmatrix} \mapsto \begin{pmatrix} e^x \cdot \cos(y) \\ e^x \cdot \sin(y) \end{pmatrix}.$$
#
#
# This exercise aims at visualizing this function by using the HSV color space.

# #### 1. 
# Create a Cartesian grid of points over $(x,y) \in [-1,1] \times [-2\pi,2\pi]$ as shown in the lecture.
#  Evaluate the exponential function for all points on the grid.
#  Translate the result to polar coordinates (as shown in the lecture).

# +
# Create the grid
extent = (-1, 1, -2*np.pi, 2*np.pi)
delta = 0.05

# function arange: from a to b with stepsize delta
# alternative - linrange: from a to b in n steps
x = np.arange(extent[0], extent[1], delta)
y = np.arange(extent[2], extent[3], delta)
# make a 2d array for plotting
X, Y = np.meshgrid(x, y)

# +
# evaluate the exponential function for all the points in the grid
Ex = np.exp(X) * np.cos(Y)
Ey = np.exp(X) * np.sin(Y)

# and translate to polar coordinates
# Polar Co-ord
# Z = r(cos(phi) + i.sin(phi)) = (r, phi)

# r = distance of point (x,y) from origin = square-root(x^2 + y^2)
R = (Ex**2 + Ey**2) ** 0.5

# phi = angle of point (x,y) to X axis
# note: most of the off-the-shelf functions (arctan, arccos, angle) return values
# in the range [-pi, pi], while we need them in [0; 2pi]
Phi = np.mod( np.arctan2(Ey,Ex) , 2*np.pi)


## Alternatively, skipping the complex->polar, 
## going directly from the original X,Y
# R = np.exp(X)
# Phi = np.mod(Y, 2*np.pi)
# -

# #### 2. 
#
# As in the lecture, create an empty array for the HSV image over the grid.
#
#  Set the hue values according to the angle of the polar coordinates, set the saturation to 1, set the value according to the radius of the polar coordinates.
#
#  Convert the image to RGB and display the result.

# +
# Empty array for the HSV image
imgHSV = np.zeros(R.shape+(3,), dtype=np.double)

# set the values as specified
# NOTE: the values need to be normalized; we could also use theoretical values for max here
imgHSV[:,:,0] = Phi / Phi.max()
imgHSV[:,:,1] = 1.0
imgHSV[:,:,2] = R / R.max() 

# convert to RGB
imgRGB = matplotlib.colors.hsv_to_rgb(imgHSV)

# +
# flip image for better visualization
imgDisp = imgRGB.transpose((1,0,2))
# reverse first axis
imgDisp = imgDisp[::-1]
fig = plt.figure(figsize=(8,2))
plt.imshow(imgDisp,extent=extent[2:]+extent[:2])

plt.xlabel("y")
plt.ylabel("x")
plt.tight_layout()
plt.show()
# -

# # 2.3 Particle colocalization
# #### We will perform a simple toy example for colocalization analysis of particle species.

# #### 1.
#
# Download the the problem-sheet-02_proteins.npz from StudIP and import it with _np.load_ into Python. It contains three grey level images, stored as keys "A", "B", and "C" in the imported object.
#  Display them.
#
#  Each image represents the observed distribution of a corresponding particle species (e.g. proteins in super-resolution microscopy experiments). We want to find out if the locations of species "A", "B", and "C" are correlated or not.

testResults = np.load("problem-sheet-02_proteins.npz")
imgA = testResults["A"]
imgB = testResults["B"]
imgC = testResults["C"]

# +
fig = plt.figure(figsize=(12,4))

fig.add_subplot(1,3,1)
plt.imshow(imgA)

fig.add_subplot(1,3,2)
plt.imshow(imgB)

fig.add_subplot(1,3,3)
plt.imshow(imgC)

plt.tight_layout()
plt.show()
# -

# #### 2. 
#
# One way to study visually whether two intensity images are correlated is by superimposing them, e.g. as different channels of a multi-color image. Choose a concrete way to do this and describe how can one qualitatively distinguish correlated and uncorrelated images.
# Apply this to the pairs ("A","B") and ("A","C") and form a conjecture about which two images are correlated.

# +
# create an empty array
imgAB = np.zeros(imgA.shape+(3,))

# overwrite the red channel with A
imgAB[:,:,0] = imgA
# overwrite the green channel with B
imgAB[:,:,1] = imgB
# normalize
imgAB = imgAB/np.max(imgAB)

# plot
plt.imshow(imgAB)
# -

# performa the same with A vs C
imgAC = np.zeros(imgA.shape+(3,))
imgAC[:,:,0] = imgA
imgAC[:,:,1] = imgC
imgAC = imgAC/np.max(imgAC)
plt.imshow(imgAC)

# plot them next to each other to compare
fig = plt.figure(figsize=(8,4))
fig.add_subplot(1,2,1)
plt.imshow(imgAB)
fig.add_subplot(1,2,2)
plt.imshow(imgAC)
plt.tight_layout()

# What can we see in the plot above: The left imag contains a lot of yellow and black, the right one mostly looks like reds and greens. That means that in the left image, the particles are located somewhat similarly in the two overlayed images, while in the right image the particles are mostly not located in the same spots, so we can see them separately in their respective red and green channels.
#
# From these images the conjecture is: "A" correlates with "B"; "A" does not correlate with "C".

# #### 3
#
# Finally, visualize directly the pixel-wise correlation, i.e. show the relation between the pixel-wise intensities of image "A" versus those of "B" and "C". This should give a more quantitative impression.

# +
# we first reshape both of the created AB and AC images 
flatAB = imgAB[:,:,:2].reshape((-1,2))
flatAC = imgAC[:,:,:2].reshape((-1,2))

# we can then plot them as a scatter plot plot

fig = plt.figure(figsize=(8,4))
fig.add_subplot(1,2,1)
plt.scatter(flatAB[:,0],flatAB[:,1],s=1)
plt.title("A vs B")
fig.add_subplot(1,2,2)
plt.scatter(flatAC[:,0],flatAC[:,1],s=1)
plt.title("A vs C")
plt.tight_layout()
plt.show()

# +
# alternatively (with the original images, not the ones obtained in task 2.3.2)
flatA = imgA.ravel()
flatB = imgB.ravel()
flatC = imgC.ravel()

fig = plt.figure(figsize=(8,4))
fig.add_subplot(1,2,1)
plt.scatter(flatA,flatB,s=1)
plt.title("A vs B")
fig.add_subplot(1,2,2)
plt.scatter(flatA,flatC,s=1)
plt.title("A vs C")
plt.tight_layout()
plt.show()
# -

# In the image on the left the data are more aligned along the diagonal, while on the right we see a much less organized behavior. The left image corresponds to a higher correlation in the data, thus supporting the conjecture we formed above.


