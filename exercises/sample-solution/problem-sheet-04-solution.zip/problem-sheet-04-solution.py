# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# +
import numpy as np
import scipy
import scipy.io as sciio
import sklearn.manifold
import imageio

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm

matplotlib.rc('image', interpolation='nearest')
matplotlib.rc('figure',facecolor='white')
matplotlib.rc('image',cmap='viridis')

prop_cycle = plt.rcParams['axes.prop_cycle']
colors = prop_cycle.by_key()['color']

# %matplotlib inline
# -

# # 4.1 PCA on deformations

# Consider the square $[−1, 1] ∈ R^2$, discretized by a uniform grid with _nPts = 15_ points along each
# axis. The file _UVData.npz_ contains an array UVData with dimensions _nMaps × 2 × nPts × nPts_.
# For each _i_ in _range(nMaps)_, the pair _U,V = UVData[i]_ encodes a deformation of this grid, where
# _U_ contains the horizontal and _V_ the vertical coordinates. As reference, _UVData.mat_ also contains
# the arrays _X_ and _Y_ that contain the original horizontal and vertical positions of the undeformed
# grid points.

# 1. Display the first five deformations, e.g. as in the reference figure in the task sheet. Briefly comment on what types of deformations you can see.

# load the data
data = np.load('UVData.npz')
UVData = data['UVData']
X = data['X']
Y = data['Y']

# +
# plot the first 5 deformations
fig=plt.figure(figsize=(5,20))
for i in range(5):
    ax = fig.add_subplot(5,1,i+1)
    # get the pair U,V describing the frid deformation
    U,V = UVData[i]
    # first plot the horizontal lines 
    # note: fix color to (for example) black, otherwise each line
    #       will be of a new color
    for x,y in zip(U,V):
        ax.plot(x,y,c="k")
    # add the vertical lines
    for x,y in zip(U.transpose(),V.transpose()):
        ax.plot(x,y,c="k")
    ax.set_title("Deformation #" + str(i+1))
    ax.set_aspect('equal')
    # setup the xticks and yticks so that they are all same
    ax.set_xticks(np.linspace(-1,1,5))
    ax.set_yticks(np.linspace(-1,1,5))
    
plt.tight_layout()
plt.show()


# -

# The first several deformations seem to be:
# 1. Scalin along vertical direction + small rotation + small Gaussian shrinkage (bottom left) and expansion (top right).
# 2. Even more rotation and again shrinkage (top right) and expansion (bottom left) + small scaling along one axis.
# 3-5 similar deformations, mostly rotation + shrinkage/expansion/
#
# It has to be noted that when one of the deformations is prevailing, it can be hard to notice the others.

# ### 2. 
# Now apply PCA to the collection of deformations. Interpret each pair _(U, V)_ as a one-dimensional
# vector of length $2 · nPoints^2$, i.e. interpret _UVData_ as two-dimensional array
# of dimension $nMaps × (2 · nPoints^2)$ and perform PCA on it, as shown in the lecture.
#
# Visualize the eigenvalues and their cumulative sum. 
#
# How many modes / eigenvalues are
# needed to capture at least 99% of the variance?
#
#
# Hint: Do not forget to center the data before applying PCA.

# +
# PCA function (from the lecture)

# do simple PCA on data matrix
# dataMat is assumed to be centered, matrix of shape (nSamples,dimSample)
def PCA(dataMat,keep=None):
    nSamples,dim=dataMat.shape
    if dim<nSamples:
        if keep is None:
            keep=dim
        A=dataMat.transpose().dot(dataMat)/nSamples
        eigData=np.linalg.eigh(A)
        eigval=(eigData[0][-keep::])[::-1]
        eigvec=((eigData[1][:,-keep::]).transpose())[::-1]
    else:
        if keep is None:
            keep=nSamples
        A=dataMat.dot(dataMat.transpose())/nSamples
        eigData=np.linalg.eigh(A)
        eigval=(eigData[0][-keep::])[::-1]
        eigvec=((eigData[1][:,-keep::]).transpose())[::-1]

        eigvec=np.einsum(eigvec,[0,1],dataMat,[1,2],[0,2])
        # renormalize
        normList=np.linalg.norm(eigvec,axis=1)
        eigvec=np.einsum(eigvec,[0,1],1/normList,[0],[0,1])
    return eigval,eigvec


# +
# As by the hint: center the data before applying PCA
nMaps = UVData.shape[0]
# reshape into nMaps x (2*nPoints*nPoints)
UVData_flat = UVData.reshape((nMaps,-1))
# compute the means of each: note the use of axis=0 parameter!
UVMean = np.mean(UVData_flat,axis=0)
# subtract the means to get centered data
UVData_centered = UVData_flat - UVMean

# apply the PCA
eigval,eigvec = PCA(UVData_centered)

# +
# Visualize the eigenvalues and their cumulative sum.
fig = plt.figure(figsize = (8,4))
fig.add_subplot(1,2,1)
# plot the eignevalue vs the index of the eigenvalue
# (note: they are already sorted max to min, by PCA function)
plt.scatter(range(eigval.shape[0]),eigval,marker="x")
plt.title("PCA spectrum")
plt.yscale("log")
plt.xlabel("Eigenvalue #")
plt.ylabel("Eigenvalue")

fig.add_subplot(1,2,2)
# plot the cumulative sum of the eigenvalues (normalized)
plt.plot(np.cumsum(eigval)/np.sum(eigval),lw=1,marker="x")
plt.axhline(y=0.99,c="r")
plt.title("Cumulative variance")
plt.xlabel("Eigenvalue #")
plt.ylabel("Cumulative variance")


plt.tight_layout()
plt.show()
# -

# ### How many modes / eigenvalues are needed to capture  at least 99% of the variance?

# +
# We can see that from the cumulative variance plot above
# (repeat the plot here and zoom in)

fig = plt.figure(figsize = (4,4))

plt.plot(np.cumsum(eigval)/np.sum(eigval),lw=1,marker="x")
plt.title("Cumulative variance")
plt.xlabel("Eigenvalue #")
plt.ylabel("Cumulative variance")
plt.axhline(y=0.99,c="r")

# zoom in onto the first 6: after that the curve is almost flat=1
plt.xlim([0,5])

plt.tight_layout()
plt.show()
# -

# We can also look at the values:
(np.cumsum(eigval)/np.sum(eigval))[:6]

# From this array we can see that already the third value is 
# larger than 0.99:
(np.cumsum(eigval)/np.sum(eigval))[2]

# ### 3
# Now try to visualize the ‘meaning’ of the first three modes, similar to the example from the
# lecture with the Gaussian curves. I.e. add each eigenvector to the mean, scaled according
# to the root of the variance that it captures, and visualize the corresponding deformations.
# For the first mode result could look as in the figure below, right. 
#
# What is the interpretation
# of the first three modes?
#
#
# Hint: In the course of this you need to undo the ‘flattening’ that was applied before PCA.

# +
# we are visualizing nModes = 3
# because we found out that the first 3 eigenvalues
# are already enough to capture most of the variance
nModes = 3

# we select nFrames = 7 as the number of frames to show
# the deformations
nFrames = 7

# we note the 1D size of each mesh to use when restoring the
# shape from flattened:
nPts1D = UVData.shape[-1]

# setup the figure size 
fig = plt.figure(figsize=(nModes*5,4))

for i in range(nModes):
    # add a new subplot
    ax = fig.add_subplot(1,3,i+1)
    # compute the scale as sqrt(eigenvalue)
    scale = eigval[i]**0.5
    # define the coefficients for visualizing deformations
    vList = np.linspace(-1,1,nFrames)
    
    # get the data representing the deformations 
    # (see the lecture for more explanations)
    # note: don't forget to add the mean back!
    dataRe = np.einsum(eigvec[i],[0],vList*scale,[1],[1,0])+UVMean
    
    # now, plot each deformation
    for v,y in zip(vList,dataRe):
        # here v represents the frame and is used for color-coding
        #      y is the actual dataset
        
        # first, get the U and V back from the flattened array
        U = y[:nPts1D**2].reshape((nPts1D,nPts1D))
        V = y[nPts1D**2:].reshape((nPts1D,nPts1D))
        
        # then, plot the maps (the same code as in exercise 4.1.1)
        for x,y in zip(U,V):
            ax.plot(x,y,c=cm.coolwarm(0.5*v+0.5))
        for x,y in zip(U.transpose(),V.transpose()):
            ax.plot(x,y,c=cm.coolwarm(0.5*v+0.5))
            
    # add subtitles
    plt.title("Mode {:d}".format(i+1))
    # setup the xticks and yticks so that they are all same
    ax.set_xticks(np.linspace(-1,1,5))
    ax.set_aspect('equal')
    ax.set_yticks(np.linspace(-1,1,5))
    
plt.tight_layout()
plt.show()


# -

# Now that we plotted the first three modes, we can actually see that each of them represents one of the deformations that we saw in exercise 4.1.1: Mode 1 represents rotation, Mode 2 represents scaling along the y axis, Mode 3 represents two Gaussian deformations (shrinking and expanding) applied in bottom left corner and top right corner correspondingly.
#
# And as the first three modes are capturing more than 99% of the variance, we can conclude that most of the deformations that constitute the dataset consist of combinations of these three modes.

# # 4.2 Damped pendulum

# Consider a mathematically idealized damped pendulum with angle θ and angular velocity ω with the equation of motion given by $$\cdot$$
#
# $$  \begin{pmatrix}\partial_t \theta(t) \\ \partial_t \omega(t) \end{pmatrix} = 
# 	F\begin{pmatrix} \theta(t) \\ \omega(t) \end{pmatrix}
# 	=\begin{pmatrix} \omega(t) \\ -\alpha\cdot \omega(t) - \beta\cdot \sin(\theta(t)) \end{pmatrix}$$
#
# which are to be solved for some initial (θ(0), ω(0)). 
#
# Here, α ≥ 0 is a coefficient describing the
# strength of friction; 
#
# β is a coefficient describing the length of the pendulum and the strength of
# gravity. 
#
# We set α = 0.15, β = 5.

# #### 1. 
# Create a quiver plot of the vector field F on $(\theta,\omega) \in [-\pi,\pi] \times [-6.5,6.5]$.

# we first define the function describing the vector field
def F(omega, theta, alpha, beta):
    return np.array([omega, -alpha*omega - beta*np.sin(theta)])


# +
theta = np.linspace(-np.pi,np.pi,20)
omega = np.linspace(-6.5, 6.5, 20)

Theta,Omega = np.meshgrid(theta,omega)

alpha = 0.15
beta = 5
f = F(Omega,Theta, alpha, beta)

plt.figure(figsize=(14,7))
ax = plt.gca()
ax.set_aspect(1)

plt.quiver(Omega,Theta, f[1,:],f[0,:], pivot ="mid")
plt.xlabel(r"$\omega$")
plt.ylabel(r"$\theta$")


plt.yticks(np.linspace(-np.pi,np.pi,5),["$-\pi$", "$-\pi/2$", "$0$", "$\pi/2$", "$\pi$"]);
# -

# #### 2. 
# Instead of merely using the streamplot function of matplotlib, we will create our own trajectory plot. For initial configurations
#
# $$	\begin{pmatrix} \theta(0) \\  \omega(0) \end{pmatrix} = \begin{pmatrix} \pi/2 \\  0 \end{pmatrix}
# 	\qquad \text{and} \qquad
# 	\begin{pmatrix} \theta(0) \\  \omega(0) \end{pmatrix} = \begin{pmatrix} 0 \\ 6 \end{pmatrix} $$
#     
# solve the above ODE numerically on $t \in [0,10]$. 
#
# This can be done quickly with the function _scipy.integrate.odeint_ (see its documentation for the pendulum example) or _scipy.
# integrate.solve_ivp_ and add these trajectories to the quiver plot. Recall what we learned
# about trajectory plots.
#
#
# Hint: In the second configuration you must be careful about the cyclic structure of $\theta$.

# +
# we copy the function for pendulum from scipy.integrate.odeint help
from scipy.integrate import odeint

def pend(y, t, b, c):
    theta, omega = y
    dydt = [omega, -b*omega - c*np.sin(theta)]
    return dydt


# +
# set up initial conditions
y0_1 = [np.pi/2, 0]
y0_2 = [0, 6]

# pick sufficient number of steps
t = np.linspace(0,10,1001)

# solve with two sets of initial conditions
sol_1 = odeint(pend, y0_1, t, args=(alpha,beta))
sol_2 = odeint(pend, y0_2, t, args=(alpha,beta))

# +
# we can first plot the solutions in the parametrized space
fig = plt.figure(figsize = (8,4))
fig.add_subplot(1,2,1)
plt.plot(t, sol_1[:, 0], 'b', label=r'$\theta$(t)')
plt.plot(t, sol_1[:, 1], 'g', label=r'$\omega$(t)')
plt.yticks(np.linspace(-np.pi,np.pi,5),["$-\pi$", "$-\pi/2$", "$0$", "$\pi/2$", "$\pi$"]);
plt.legend(loc='best')
plt.xlabel('t')
plt.title("Solution 1: y0 = [$\pi$/2, 0]")
plt.grid()

fig.add_subplot(1,2,2)
plt.plot(t, sol_2[:, 0], 'b', label=r'$\theta$(t)')
plt.plot(t, sol_2[:, 1], 'g', label=r'$\omega$(t)')
plt.yticks(np.linspace(-np.pi,5*np.pi,7),["$-\pi$", "$0$", "$\pi$","$2\pi$", "$3\pi$", "$4\pi$","$5\pi$"]);
plt.legend(loc='best')
plt.title("Solution 2: y0 = [0, 6]")
plt.xlabel('t')
plt.grid()


plt.show()
# -

# With the help of these plots, we can see the major difference immediately: in the first case, we are in the _classical_ regime when the pendulum is oscillating with the energy dissipating from the system, as the angular velocity and the angle are oscillating with decreasing amplitude.
#
# On the right side, however, we see that the angle $\theta$ is going out of the $[-\pi, \pi]$ range, which should be understood in mod($2\pi$) sense, so it corresponds to the pendulum performing 2 full rotations before coming to the regime that we saw in the first plot.
#
# We now need to plot the same data in the phase space.

# +
# we first identify the points where a new part of the 
# trajectory should start and create a list of indices
# to denote the starts of new curves

# also modify the array with the solution itself (so we create a 
# # copy of it beforehand to prevent losing it)
sol_2_fixed = sol_2.copy()

# we add the first element as initialization
indList = [0]
for i in range(sol_2.shape[0]):
    # if the angle went above pi
    if sol_2[i,0] >= np.pi:
        # we remember the iteration
        indList.append(i)
        # and decrease every value after that by 2pi
        sol_2[i:,0] -= 2*np.pi
indList.append(sol_2.shape[0])

# +
# and now we can plot the curves

plt.figure(figsize=(14,7))
ax = plt.gca()
ax.set_aspect(1)

# same quiver as in 4.3.1
plt.quiver(Omega, Theta, f[1,:], f[0,:], pivot='mid')

# plot the "easy" solution nr 1
plt.plot(sol_1[:,1],sol_1[:,0],color="blue")
# add start and end points for better readability
plt.scatter(sol_1[0,1],sol_1[0,0],color="blue",marker='x')
plt.scatter(sol_1[-1,1],sol_1[-1,0],color="blue",marker='o')

# now plot solution nr 2 piece by piece
for i in range(len(indList)-1):
    plt.plot(sol_2[indList[i]:indList[i+1],1],sol_2[indList[i]:indList[i+1],0],color="red")
# add start and end points
plt.scatter(sol_2[0,1],sol_2[0,0],color="red",marker='x')
plt.scatter(sol_2[-1,1],sol_2[-1,0],color="red",marker='o')

plt.xlabel(r"$\omega$")
plt.ylabel(r"$\theta$")

plt.yticks(np.linspace(-np.pi,np.pi,5),["$-\pi$", "$-\pi/2$", "$0$", "$\pi/2$", "$\pi$"]);

# +
# alternatively, one could use the scatter function 
# to plot the second solution, but then the solution
# should be computed on a very dense t set

# in this case, we don't need to go through all the array
# element by element, we can just take a mod 2pi
# so we look at the following implementation
# (as the first step we retrieve the original solution)
sol_2 = sol_2_fixed.copy()

sol_2[:,0] = np.mod(sol_2[:,0] + np.pi, 2*np.pi) - np.pi

plt.figure(figsize=(14,7))
ax = plt.gca()
ax.set_aspect(1)

plt.quiver(Omega,Theta, f[1,:],f[0,:], pivot ="mid")
plt.xlabel(r"$\omega$")
plt.ylabel(r"$\theta$")

plt.yticks(np.linspace(-np.pi,np.pi,5),["$-\pi$", "$-\pi/2$", "$0$", "$\pi/2$", "$\pi$"]);

plt.plot(sol_1[:,1],sol_1[:,0],color="blue")
plt.scatter(sol_1[0,1],sol_1[0,0],color="blue",marker="x")
plt.scatter(sol_1[-1,1],sol_1[-1,0],color="blue",marker="o")

# note: here is the main difference: we use the scatter
# function, so the nearest elements are not automatically
# connected by a straight line
plt.scatter(sol_2[:,1],sol_2[:,0],color="red", s = 1)
plt.scatter(sol_2[0,1],sol_2[0,0],color="red",marker="x")
plt.scatter(sol_2[-1,1],sol_2[-1,0],color="red",marker="o")
# -

# #### 3.
# Briefly answer the following questions: What is the major difference between the two trajectories
# and what does it mean for the pendulum’s behaviour in each case? Qualitatively,
# how would the trajectories change if $\alpha$ were increased?

# The behavior of the pendulum is already discussed above.
#
# Now, for parameter $\alpha$, we can see from the equations that the physical meaning of the parameter is damping, and the higher the value, the more damping is introduced in the system, and so the faster is the energy dissipating - the trajectories should become tighter around the origin.
#
# We can also confirm this hypothesis with a couple of numerical experiments.

# +
# set up initial conditions
y0_1 = [np.pi/2, 0]

# pick sufficient number of steps
t = np.linspace(0,10,1001)

beta = 5

plt.figure(figsize=(7,7))
ax = plt.gca()
ax.set_aspect(1)
plt.xlabel(r"$\omega$")
plt.ylabel(r"$\theta$")

plt.yticks(np.linspace(-np.pi,np.pi,5),["$-\pi$", "$-\pi/2$", "$0$", "$\pi/2$", "$\pi$"]);


# solve with two sets of initial conditions
for alpha in np.logspace(-3,0,5):
    sol_1 = odeint(pend, y0_1, t, args=(alpha,beta))
    plt.plot(sol_1[:,1],sol_1[:,0],label=r"$\alpha={:f}$".format(alpha))

plt.legend(loc="best")
# -

# # 4.3 Multi-dimensional scaling (bonus)

# The file _mds.npz_ contains the array _d2_ of dimension nPts x nPts giving the matrix of squared distances of a point cloud
# of nPts = 500 points, originally embedded in $\mathbb{R}^3$.

# ### 1. 
# Use MDS as in the lecture to reconstruct the embedding. Visualize the best approximate embeddings into 2 and 3 dimensions. Describe in a few words the ‘shape’ of the 3d embedding.

d2 = np.load("mds.npz")["d2"]


# +
# use functions from the lecture
def getGramMatrix(d2):
    """Recover gram matrix from squared distance matrix, this will be pos-definite
    if and only if distance matrix has Euclidean embedding."""
    d2Avg=np.mean(d2,axis=1)
    K=0.5*(d2Avg.reshape((-1,1))+d2Avg.reshape((1,-1))-d2)
    K-=np.mean(K)
    return K

def getMDSEmbedding(K):
    eigdat=np.linalg.eigh(K)
    eigval=eigdat[0][::-1]
    eigvec=eigdat[1].transpose()[::-1].copy()
    del eigdat
    y=np.einsum(eigvec,[0,1],np.maximum(0,eigval)**0.5,[0],[1,0])
    return eigval,eigvec,y


# -

# apply the MDS embedding method from the lectures
K = getGramMatrix(d2)
eigval,eigvec,y = getMDSEmbedding(K)

# +
# plot the eigenvalues
# note that the first 3 values are much larger than the other
# %matplotlib inline

fig = plt.figure(figsize=(6,3));
plt.plot(np.abs(eigval),marker="x",lw=0)
plt.yscale("log")
plt.tight_layout()
plt.xlabel("Nr of eigenvalue")
plt.ylabel("Absolute value of eigenvalue (log-scale)")
plt.show()


# +
# 2D
# %matplotlib inline
fig = plt.figure(figsize=(6,3));

plt.scatter(y[:,0],y[:,1])
plt.tight_layout()
plt.show()

# -

# We see some regular oscillations with (seemingly) constant amplitude and frequency, the mean seems to be increasing.

# +
# %matplotlib widget

fig = plt.figure(figsize=(5,5))
ax = fig.add_subplot(111, projection='3d')
# aspect ratio']
lim=np.max(np.abs(y[:,:3]))*1.1
ax.set_xlim([-lim,lim])
ax.set_ylim([-lim,lim])
ax.set_zlim([-lim,lim])
ax.set_box_aspect((1.,1.,1.))

ax.scatter(y[:,0],y[:,1],y[:,2])
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("z")
plt.tight_layout()
plt.show()
# -

# Again we see regular oscillations, but in 3D we are also able to see the extra dimension, "the width".

# ### 2.
# How can you tell that the original point cloud must probably have been three dimensional?
# The original point cloud had features on three different length scales (things like ‘length’
# or ‘period of some oscillation’). What are these features? Which feature is missing in the
# approximate 2-dimensional embedding?

#
#
# The first and most quantative characteristic which tells us that the original data is more likely 3-dimensional is the eigenvalues: the first 3 eigenvalues are much larger than the rest (they have the order of $10^1-10^{-1}$, while the rest are below $10^{-14}$). 
#
# We can also compare the embeddings in 2D and 3D and notice that we can find a plane in 3D (by rotating the plot in the widget), where we almost find a projection similar to 2D. However, we can also see that the plot has the "width" (in the axis orthogonal to the plane of the oscillations), and the width seems to be rather consistent through the plot.

# ### 3.
# Use _sklearn.manifold.MDS_ to get approximate 2- and 3-dimensional embeddings. Briefly
# comment on whether they are comparable.
#
# Hints: Use the keyword _dissimilarity=’precomputed’_ and use the (entry-wise) square
# root of d2 as proxy for dissimilarity.

# +
# 2 components
embedding = sklearn.manifold.MDS(n_components=2, dissimilarity='precomputed', normalized_stress='auto')
y = embedding.fit_transform(d2**.5)

# %matplotlib inline

fig = plt.figure(figsize=(6,3));
plt.scatter(y[:,0],y[:,1])
# -

# Note that the embedding changes with every run of the function, however some features we can see every time: The regular nature of oscillations (amplitude, frequency), linearly changing mean (might be indresing or descreasing), the general scaling.

# +
# 3 components
embedding = sklearn.manifold.MDS(n_components=3, dissimilarity='precomputed', normalized_stress='auto')
y = embedding.fit_transform(d2**.5)

# %matplotlib widget

fig = plt.figure(figsize=(5,5));
ax = fig.add_subplot(111, projection='3d');
# aspect ratio
lim=np.max(np.abs(y[:,:3]))*1.1
ax.set_xlim([-lim,lim])
ax.set_ylim([-lim,lim])
ax.set_zlim([-lim,lim])
ax.set_box_aspect((1.,1.,1.))

ax.scatter(y[:,0],y[:,1],y[:,2]);
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("z")
plt.tight_layout()
plt.show()

# -

# Again, from run to run the plot might change, however the nature of the plot remains the same, as discussed for the previous plots.


