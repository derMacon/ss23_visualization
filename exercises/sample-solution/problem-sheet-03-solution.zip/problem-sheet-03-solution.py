# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# # Problem sheet 03

# libraries
import numpy as np
import scipy
import scipy.io as sciio
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
# %matplotlib inline

# # 3.1 smoking and life expectancy
#
# ### 1.
#
# The file smokers.npz contains an array data of dimensions Npers x 3 of type int which contains information about Npers = 20,000 persons from Ncountries = 20 countries.
#
# Each row represents one person. The first column encodes the country that they live in, by an integer from 0 to 19. 
#
# The second column encodes whether that person was a regular smoker (=1) or not (=0). 
#
# The third column gives the age in full years that this person reached at the time of their death. 
#
# Import this array into python

data = np.load("smokers.npz")["data"]

# ### 2.
#  Plot histograms over ages for the total population, for smokers and non-smokers (with absolute counts in each bin). 
#
# In addition, plot the normalized histograms (where entries in all bins sum to one), which represent an approximate probability density function.

# +
# make histogram of the total population
data_all = data[:,2]
nBins = 20
hist_all,edges_all = np.histogram(data_all, nBins)

# plot it (note, the 0 is added as the first element of the array)
fig = plt.figure(figsize=(9,4))
plt.step(edges_all, np.concatenate( (np.zeros(1),hist_all) ), c = "black")
plt.xlabel("Age")
plt.ylabel("Nr of persons")

# +
# similarly, make histogram for all, smokers, and non-smokers together

nBins = 20

# histogram for all
data_all = data[:,2]
hist_all,edges_all = np.histogram(data_all, nBins)

# select only non-smokers, make histogram
ind = (data[:,1]==0)
data_non = data[ind,2]
hist_non,edges_non = np.histogram(data_non, nBins)

# select only smokers, make histogram
ind=(data[:,1]==1)
data_smo = data[ind,2]
hist_smo,edges_smo = np.histogram(data_smo, nBins)

# now plot similarly to the one above
# only difference: with 3 lines in the plot, need to be able to 
# distinguish them -> color parameter + legend
fig = plt.figure(figsize=(9,4))
plt.step(edges_all, np.concatenate( (np.zeros(1),hist_all) ), c = "black")
plt.step(edges_non, np.concatenate( (np.zeros(1),hist_non) ), c = "blue")
plt.step(edges_smo, np.concatenate( (np.zeros(1),hist_smo) ), c = "red")
plt.xlabel("Age")
plt.ylabel("Nr. of persons")
plt.legend( ("All","Non-smokers","Smokers") )

# +
# for normalized histograms, we use the previously computed histogram data
# and divide the values in them by the total sum of elements
# now, normalized
fig = plt.figure(figsize=(9,4))
plt.step(edges_all, np.concatenate( (np.zeros(1),hist_all/np.sum(hist_all)) ), c = "black")
plt.step(edges_non, np.concatenate( (np.zeros(1),hist_non/np.sum(hist_non)) ), c = "blue")
plt.step(edges_smo, np.concatenate( (np.zeros(1),hist_smo/np.sum(hist_smo)) ), c = "red")
plt.xlabel("Age")
plt.ylabel("Nr. of people (normalized)")
plt.legend( ("All","Non-smokers","Smokers") )

# making a normalized histogram allows comparing the profiles
# in this case we can more clearly see the red histogram (smokers)
# -

# ### 3.
# For each country, determine the average life expectancy of people and the fraction of smokers. Visualize this information.

# +
# first: process the data, grouping persons by country

nCountries = 20

# we'll make 3 lists, each consisting of 20 lists, where the values
# corresponding to the countries will be stored

list_all = []
list_smoke = []
list_non = []
for i in range(nCountries):
    # indicator array of all people living in that country
    ind = (data[:,0]==i)
    list_all.append(data[ind,2])

    # indicator array of all smokers living in that country
    ind = (data[:,0]==i)&(data[:,1]==1)
    list_smoke.append(data[ind,2])

    # indicator array of all non-smokers living in that country
    ind = (data[:,0]==i)&(data[:,1]==0)
    list_non.append(data[ind,2])

# +
# now that they are in lists, let's compute the mean and count the smokers
# and non-smokers
mean_all = np.array([np.mean(x) for x in list_all])
mean_smoke = np.array([np.mean(x) for x in list_smoke])
mean_non = np.array([np.mean(x) for x in list_non])

count_all = np.array([len(a) for a in list_all])
count_smoke = np.array([len(a) for a in list_smoke])
count_non = np.array([len(a) for a in list_non])

# fraction of smokers
smokers_fraction = count_smoke/count_all

# +
# let's just plot them next to each other
# for that, we need to order the countries

# order countries by mean life expectancy
order = np.argsort(mean_all) 
# array order gives the indices of the countries in increasing order of
# the mean life expectancy (that is, meal_all[order] is sorted)

# it would be convenient to also have the "inverse" of that array:
# if I have the country from the original list, in which position
# is it in the list of all countries?
orderInv=np.zeros_like(order)
orderInv[order]=np.arange(nCountries)

# for example, if I am interested in country nr. 2, I would request
# orderInv[2] and the result (equal 15) will tell me: 
# country number 2 is in 15th place by the average life expectancy 
# so it means, that if I request order[15], I should get 2 

# +
# now we plot the life expectancy and
# the smokers fraction in the order of life expectancy

fig = plt.figure(figsize=(11,4))
fig.add_subplot(1,2,1)
plt.plot(mean_all[order])
plt.scatter(range(nCountries), mean_all[order])
plt.xticks(range(nCountries), labels = order);
plt.xlabel("Country")
plt.ylabel("Avg life expectancy")

fig.add_subplot(1,2,2)
plt.plot(smokers_fraction[order])
plt.scatter(range(nCountries), smokers_fraction[order])
plt.xticks(range(nCountries), labels = order);
plt.xlabel("Country")
plt.ylabel("Fraction of smokers")
plt.show()
# -

# Please note that it was not necessary to order the countries for these plots (the ordering was only requested in task 3.2.5) but by ordering by country we can actually see the trends, and therefore connecting the datapoints makes sense.
#
# Without ordering, connecting points would be a mistake because there is no interpolation possible between countries.
#
# Also note that if you use scatter plots without order, you still need to take care of the ticks: by default, the ticks will be just float numbers in the range between 0 and 19, and in this case it is not appropriate; the id of the country should be shown as the corresponding tick lable.

# +
# it seems that both lines have an increasing trend, so maybe there is
# some kind of correlation between them. Because of them, we plot
# just Avg life expectancy vs Fraction of smokers 

plt.scatter(mean_all,smokers_fraction)
plt.xlabel("Avg life expectancy")
plt.ylabel("Fraction of smokers")
plt.show()

# looks very linear, probably somewhat correlated data
# -

# ### 4
# For each country, determine the life expectancy of smokers and non-smokers. Visualize this information.

# +
# We have already computed the needed information, now we just plot the
# data in the avg-life-expectancy order

fig = plt.figure(figsize=(11,4))
fig.add_subplot(1,2,1)
plt.plot(mean_non[order])
plt.scatter(range(nCountries),mean_non[order])
plt.xticks(range(nCountries), labels = order);
plt.xlabel("Country")
plt.ylabel("Avg. life expectancy (non-smokers)")

fig.add_subplot(1,2,2)
plt.plot(mean_smoke[order])
plt.scatter(range(nCountries),mean_smoke[order])
plt.xticks(range(nCountries), labels = order);
plt.xlabel("Country")
plt.ylabel("Avg. life expectancy (smokers)")
plt.show()
# -

# Again, it somehow seems that these to curves are similar, so we can try a scatter plot
#

# +
# display life exp of smokers vs non-smoker on per-country basis
plt.scatter(mean_non,mean_smoke)

# seems like there is a linear trend, so we first plot diagonal ("y = x")
diagon = np.linspace(50,100)
plt.plot(diagon,diagon,ls="solid",color="gray")

# and since the points seem to be below the diagonal with a roughly
# constant shift, we can just try and guess it
# reminder: the goal is not to actually get the parameters of
# the linear regression, but just to see quickly if the data
# show a linear trend close to the diagonal

# also note that since we have to shift the diagonal down to fit, it 
# suggests that the life expectancy of smokers is lower than the non-smokers
plt.plot(diagon,diagon-5,ls="dashed",color="gray")
plt.xlabel("Avg. life expectancy (non-smokers)")
plt.ylabel("Avg. life expectancy (smokers)")
plt.show()
# -

# ### 5. 
#
# Generate a 2d histogram of people over their country and their age, for smokers and nonsmokers.
#
# Find a way to visualize this in a single plot as a multi-color image.
#
# Hints: Think about a good way of normalizing the color channels. 
#
# Think about a reasonable
# ordering of the countries.

# +
# we start by creating 2 separate 2D histograms: 
# one for smokers, one for non-smokers

# what we want for each of them is the histogram for age, 
# but separately for each of the countries

# also we have to think that we will need to merge the histograms eventually
# so we need to fix the ranges within each binning

# for that, let's just take the lowest and the largest ages
min_age = np.min(data[:,2])
max_age = np.max(data[:,2])

# and use them for binning
binrange = (min_age, max_age)
nBins = 25

# create an empty array for the 2D histogram data for smokers
hist_smo2D = np.zeros((nCountries, nBins))

for i in range(nCountries):
    # smokers from country i (almost as in 3.2.2 + select by country)
    ind = (data[:,0]==i)&(data[:,1]==1)
    data_smo = data[ind,2]
    hist_smo,edges_smo = np.histogram(data_smo, nBins, range=binrange)
    # normalize to [0; 1] for each country
    hist_smo2D[i,:] = hist_smo/np.sum(hist_smo)

fig = plt.figure(figsize=(7,7))
    
# plot the values in order of increasing avg life expectancy
# use [order,:] to put the data in the predefined order
# use extent to correct the x-axis (ages)
# use aspect = "auto" to prevent the image from beeing squized
plt.imshow(hist_smo2D[order,:], extent=(min_age,max_age,0,nCountries-1), aspect="auto") 

# change the y-tick labels
plt.yticks(ticks = range(nCountries)[::-1], labels = order)
# note: [::-1] gives the reverse order of labels, so that we get the labels
# corresponding to the actual countries from 14 (lowest life expectancy)
# to 3 (highest)
plt.ylabel("Countries")
plt.xlabel("Ages")


# +
# We can now do the same for the non-smokers and plot them next to
# each other just to see how they look

# data for non-smokers
hist_non2D = np.zeros((nCountries, nBins))

for i in range(nCountries):   
    # non-smokers
    ind = (data[:,0]==i)&(data[:,1]==0)
    data_non = data[ind,2]
    hist_non,edges_non = np.histogram(data_non, nBins, range=binrange)
    hist_non2D[i,:] = hist_non/np.sum(hist_non)


# plot 2 subplots
fig = plt.figure(figsize=(10,5))
ax = plt.subplot(1,2,1)
plt.imshow(hist_smo2D[order,:], extent=(min_age,max_age,0,nCountries-1), aspect="auto") 

plt.yticks(ticks = range(20)[::-1], labels = order)
plt.ylabel("Countries")
plt.xlabel("Ages")
plt.title("Smokers")

ax = plt.subplot(1,2,2)
plt.imshow(hist_non2D[order,:], extent=(min_age,max_age,0,nCountries-1), aspect="auto") 

plt.yticks(ticks = range(20)[::-1], labels = order)
plt.title("Non-smokers")
plt.ylabel("Countries")
plt.xlabel("Ages")

# +
# but we need to make a SINGLE 2D histogram that incorporates these data

# First idea: plot them as 2 channels of an image
# create empty image
img = np.zeros((nCountries, nBins,3))

# find the maximum values to renormalize the histograms
# (note: without renormalizing, it's very hard to see anything)
max_smo = np.max(hist_smo2D[order,:], axis = 1)
max_non = np.max(hist_non2D[order,:], axis = 1)

img[:,:,0] = hist_smo2D[order,:]/max_smo.reshape((-1,1))
img[:,:,2] = hist_non2D[order,:]/max_non.reshape((-1,1))

# plot
fig = plt.figure(figsize=(7,7))

plt.imshow(img, extent=(min_age,max_age,0,nCountries-1), aspect="auto")
plt.yticks(ticks = range(20)[::-1], labels = order)
plt.ylabel("Countries")
plt.xlabel("Ages")
# -

#  Note that the countries are ordered and the y-labels are corresponding to the ids of the countries.
#  
#  Also note that the channels are normalized so that we can see maximally bright picture.

# +
# alternative solution: plot with alpha = 0.5
fig = plt.figure(figsize=(7,7))

plt.imshow(hist_smo2D[order,:], alpha=0.5,cmap="Reds", extent=(min_age,max_age,0,nCountries-1), aspect="auto")
plt.imshow(hist_non2D[order,:], alpha=0.5,cmap="Blues", extent=(min_age,max_age,0,nCountries-1), aspect="auto")

plt.yticks(ticks = range(20)[::-1], labels = order)
plt.ylabel("Countries")
plt.xlabel("Ages")
# -

# ### 6. 
# For smokers and non-smokers, the relation ‘country that a person lived in’ to ‘age of that
# person’ is a stochastic functional relation. 
#
# Visualize this relation for both groups (smokers,
# non-smokers) to obtain a single chart which conveys the information how long smokers and
# non-smokers tend to live in various countries and how large the variation of ages is.

# +
# first (standard) idea: box plots

# if we simply use boxplot function 2 times in the same plot for our data,
# the plots will overlap and it will be hard to get any information

# so we adjust the following parameters:
#  positions = orderInv+-0.15; so the basic value is orderInv - to make 
#            the boxes appear in the order of increasing mean; and we subtract
#            and add the same value to shift the boxes slightly left and right
#            so that they don't intersect
# widths = 0.2 - adjust the width of the boxplots
# medianprops=dict(color="red")) - color of the median

# alternatively/additionaly one could use 
# patch_artist=True, boxprops=dict(facecolor="red")
# patch_artist=True, boxprops=dict(colot="red")


fig = plt.figure(figsize = (14,7))
plt.boxplot(list_smoke, positions = orderInv-0.15, widths=0.3, medianprops=dict(color="red"));
plt.boxplot(list_non,   positions = orderInv+0.15, widths=0.3, medianprops=dict(color="blue"));
plt.xticks(range(nCountries),order);

plt.xlabel("Country")
plt.ylabel("Age")

# +
# alternatively to the box-plots, one could use violin plots
fig = plt.figure(figsize = (14,7))

plt.violinplot(list_non,  positions=orderInv+0.15,widths=0.5);
plt.violinplot(list_smoke,positions=orderInv-0.15,widths=0.5);

plt.xticks(range(nCountries),order);

plt.xlabel("Country")
plt.ylabel("Age")
# -

#  Note: one can also use sklearn package to plot violin plots, and then the parameters (e.g. color) can be adjusted easily
#  Also sklearn violinplots can easily be made into 1-side violins, so the two violins can be visualized side-by-side

# +
# another alternative: errorbar plot
fig = plt.figure(figsize = (14,7))

std_all=np.array([np.std(x) for x in list_all])
std_smoke=np.array([np.std(x) for x in list_smoke])
std_non=np.array([np.std(x) for x in list_non])

plt.errorbar(np.arange(nCountries)-0.1,mean_non[order],yerr=std_non)
plt.errorbar(np.arange(nCountries)+0.1,mean_smoke[order],yerr=std_smoke)
plt.xticks(range(nCountries),order);

plt.xlabel("Country")
plt.ylabel("Age")
# -

# Note: the means are connected by straint lines and that shows a trend because the datapoints are ordered by average life expectancy. If the plot is presented in the original order (that is, by country id from 0 to 19), there is no trend to be seen and the interpolation makes no sense: e.g. what is country 2.5?

# # 3.2 salary trends
# ### 1. 
# The file salaries.npz contains an array salaries of dimensions Npers x Nyears which contains the yearly salaries in Euros of Npers = 200 persons over Nyears = 20 years, from 2001 to 2020. In addition, it contains an array inflation_factors of dimensions Nyears x 1 with the inflation rate for Euros in percent for the years 2001 to 2019 (careful: it is formatted as array of shape 1x(Nyears - 1)). Import both arrays into python.

salaries_data = np.load("salaries.npz")
inflation_factors = salaries_data["inflation_factors"].ravel()
salaries = salaries_data["salaries"]
years = np.arange(2001,2021)

# ### 2.
# Compute the effective deflated value of one Euro in each year from 2001 to 2020 in terms of 2001 Euros.

# +
# to compute the relative value of yearly euros 
# we multiply yearly inflation (as noted in the task, the values
# are in percent)
inflation_value = np.cumprod(1 + inflation_factors/100)

# the value of the euro in the first considered year (2001) is 1
inflation_value=np.concatenate(([1.],inflation_value))

# we plot the values
fig = plt.figure(figsize=(12,4))
plt.scatter(range(years.shape[0]),inflation_value)
plt.plot(inflation_value)
plt.xticks(range(years.shape[0]),years)

plt.ylabel("Relative euro value")
plt.xlabel("Year")
plt.show()
# -

# ### 3. 
# You are a consultant for the governing party in the fictional country. From the data create a chart that demonstrates that the average salary has increased substantially over the last 20 years.

# +
# we can simply take a look at the mean income over whole population
# with no correction for inflation
meanIncome = np.mean(salaries,axis=0)

fig = plt.figure(figsize=(12,4))
plt.plot(meanIncome)
plt.xticks(range(years.shape[0]),years)

plt.ylabel("Average income")
plt.xlabel("Year")
plt.show()
# -

# **The governing party**: _As one can see from the plot above, the average income has increased almost two-fold, that definitely means that people live so much better now under our government_
#
# **Just a side note**: One might also play with the parameters of the plot itself, e.g. squeese it from the sides to highlight the fact that the growth is so steep.

# ### 4  
#
# Now you work for the opposition party. Create a chart that shows that while salaries have increased substantially for high-income groups, for a large fraction of employees the effective salaries have stagnated. Explain what data you show in your chart (1-2 sentences).

# +
# First idea would be to actually account for inflation
deflatedMean = meanIncome/inflation_value

fig = plt.figure(figsize=(12,4))
plt.plot(meanIncome)
plt.plot(deflatedMean)
plt.xticks(range(years.shape[0]),years)

plt.legend(["Non-deflated value","Deflated value"])

plt.ylabel("Average income")
plt.xlabel("Year")
plt.show()

# +
# However, we can still see that there is a positive trend
# Therefore, we investigate the suggestion that the positive trend
# might be caused by a small fraction of population
# We could therefore consider the median instead of the mean,
# as a more robust estimator

# we first prepare the data for further analysis and reevaluate
# all the salaries in deflated euro
deflatedSalaries = np.einsum(salaries,[0,1],1/inflation_value,[1],[0,1])


# we than compute the median and see a very different behavior
deflatedMedian = np.median(deflatedSalaries,axis=0)
fig = plt.figure(figsize=(12,4))
plt.plot(deflatedMedian)
plt.xticks(range(years.shape[0]),years)

plt.ylabel("Deflated median income")
plt.xlabel("Year")
plt.show()

# +
# we can also change the percentile and see different behaviors
q = 70

# we than compute the median and see a very different behavior
deflatedPercentile = np.percentile(deflatedSalaries,q,axis=0)
fig = plt.figure(figsize=(12,4))
plt.plot(deflatedPercentile)
plt.xticks(range(years.shape[0]),years)

plt.ylabel("Deflated income, {} percentile".format(q))
plt.xlabel("Year")
plt.show()

# +
# we can also cut out top n% of the respondents out of the
# set and consider the average values again
n = 10
idLowerThanN = np.arange(salaries.shape[0])
idHigherThanN = np.arange(salaries.shape[0])

# we compute the average deflated salary for 20 years for
# each person in the set
personalAvgSalary = np.mean(deflatedSalaries, axis=1)

# compute the threshold: the (100-n) percentile of average salaries
threshold = np.percentile(personalAvgSalary,100-n)

# select people with avg salaries lower than threshold
idLowerThanN = idLowerThanN[personalAvgSalary <= threshold]
idHigherThanN = idHigherThanN[personalAvgSalary > threshold]

fig = plt.figure(figsize=(12,4))
plt.plot(np.mean(deflatedSalaries[idHigherThanN],axis=0))
plt.plot(np.mean(deflatedSalaries[idLowerThanN],axis=0))

plt.xticks(range(years.shape[0]),years)

plt.legend(["Top {}% of the population".format(n),"Other {}% of the population".format(100-n)])

plt.ylabel("Average income")
plt.xlabel("Year")
plt.show()
# -

# **The opposing party**: _As one can see from the plot above, only the people with highest incomes set the positive trend, and you and I, the common people, have completely stagnating salaries; that definitely means that people live so much poorly under our government_
#
# **Just a side note**: This plot also lies very bluntantly, as one can check by removing the "top" curve from the plot and observing the positive trend.

# +
# we could try an alternative route: consider how the salaries 
# actually changed through the years by just comparing the value
# in 2001 with the salary in 2020

fig = plt.figure(figsize=(12,6))
fig.add_subplot(1,2,1)

plt.scatter(deflatedSalaries[:,0],deflatedSalaries[:,-1],marker="x")
plt.xscale("log")
plt.yscale("log")

plt.xlabel("Salary in 2001 (deflated)")
plt.ylabel("Salary in 2020")

# we can also plot the relative value of salary in 2020 against
# salary in 2001 to see the change in salary vs the initial salary
# more clearly
fig.add_subplot(1,2,2)
plt.scatter(deflatedSalaries[:,0],deflatedSalaries[:,-1]/deflatedSalaries[:,0],marker="x")
plt.xscale("log")
plt.yscale("log")

plt.xlabel("Salary in 2001 (deflated)")
plt.ylabel("Relative salary in 2020 vs 2001")

plt.tight_layout()
plt.show()


# +
# what we see in the both plots above is that 
# (1) most of the points are concentrated in the bottom left corner, 
# corresponding to small starting salary and small current salary in
# the left plot AND small starting salary and small increase in the
# right plot
# (2) people who got largrer salaries in 2001 got a larger increase

# that calls for the following plot:
# two histograms over effective salary change and initial salary

fig = plt.figure(figsize=(12,6))

fig.add_subplot(1,2,1)
plt.title("effective salary change (log)")
plt.hist(np.log(deflatedSalaries[:,-1]/deflatedSalaries[:,0]))

fig.add_subplot(1,2,2)
plt.title("initial salary (log)")
plt.hist(np.log(deflatedSalaries[:,0]))

plt.show()
# -

# **The opposing party**: _As one can see from the scatter plots and histograms above, people with high starting salaries are the ones who got a large salary increase in the past 2 decades, while the common people like you and I got no tangible raise; that definitely means that people live so much poorly under our government_
#
# **Just a side note**: This plots get the message across, but requires some extra analysis from the viewers.


